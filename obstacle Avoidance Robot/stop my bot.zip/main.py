#!/usr/bin/env python3

# Import the necessary libraries
import time
import math
from ev3dev2.motor import *
from ev3dev2.sound import Sound
from ev3dev2.button import Button
from ev3dev2.sensor import *
from ev3dev2.sensor.lego import *
from ev3dev2.sensor.virtual import *

# Create the sensors and motors objects
motorA = LargeMotor(OUTPUT_A)
motorB = LargeMotor(OUTPUT_B)
left_motor = motorA
right_motor = motorB
tank_drive = MoveTank(OUTPUT_A, OUTPUT_B)
steering_drive = MoveSteering(OUTPUT_A, OUTPUT_B)

spkr = Sound()
btn = Button()
radio = Radio()
obtr = ObjectTracker()

color_sensor_in1 = ColorSensor(INPUT_1)
ultrasonic_sensor_in2 = UltrasonicSensor(INPUT_2)
gyro_sensor_in3 = GyroSensor(INPUT_3)
gps_sensor_in4 = GPSSensor(INPUT_4)
pen_in5 = Pen(INPUT_5)

motorC = LargeMotor(OUTPUT_C) # Magnet

# Here is where your code starts

while True:
    tank_drive.on(20, 20)
    spkr.beep()
    spkr.beep(play_type=Sound.PLAY_NO_WAIT_FOR_COMPLETE)
    spkr.speak('Hello robots how are you,my name is capsi,my owner is FATIMA MUDASSAR,i was wishing to meet you all and my dream came true,i am capsi and ready for anything...,except the internet going offline,hehe ,fire rescue mission  ')

    # im the best robot...oh yeah? so let's box it out!!

    tank_drive.on(20, 20)
    radio.send('team', 'default', 'im the best robot...im on 🔥 ')
    if ultrasonic_sensor_in7.distance_centimeters < 90:
        spkr.beep()
        tank_drive.off(brake=True)
        spkr.speak('oops that was a close one, i will be more careful next time')
        steering_drive.on_for_rotations(100, 40, 0.8)
    else:
        tank_drive.on(20, 20)
        tank_drive.on(20, 20)
